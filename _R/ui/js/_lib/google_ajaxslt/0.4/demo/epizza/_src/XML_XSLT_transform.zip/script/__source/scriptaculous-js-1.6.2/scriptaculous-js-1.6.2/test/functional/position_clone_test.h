<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>prototype.js Position.clone functional test</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <script src="../../lib/prototype.js" type="text/javascript"></script>
    <script src="../../src/scriptaculous.js" type="text/javascript"></script>
    <style type="text/css">
      .margins   { margin:20px; }
      .nomargins { margin:0; }
    </style>
  </head>
  <body>


  <div id="container" style="position:relative; top:10px; width:300px; height:100px; overflow: auto;">

    <div id="container2" style="position:relative; top:10px; width:400px; height:150px; overflow: auto;">

    <div id="test1" style="border:1px solid black; position:absolute; left: 100px; top: 10px; width:100px; height:200px;">
       abs
    </div>

    <div id="test2" style="border:1px solid black; position:relative; left: 50px; top: 0px;">
       rel
    </div>

    <div id="test3" style="border:1px solid black; position:static;">
       static
    </div>

  </div>

  </div>

  <div id="c3" style="position:absolute;top:140px;left:55px;width:100px;height:20px;">
    abs-body child
  </div>

  <p id="p1" style="background-color:#eee;">
    unpositioned p 
  </p>

    <script type="text/javascript" language="javascript">
    // <![CDATA[
    function d(el, marker) {
      $('debug').innerHTML = 
        'orig:  ' + Object.inspect(Position.page($(el))) + ', ' +
        'clone: ' + Object.inspect(Position.page($(marker)));
    }
    function testA(el) {
      Position.clone(el, 'marker');
      d(el, 'marker');
    }
    function testB(el) {
      Element.hide('marker2');
      Position.clone(el, 'marker2');
      Element.show('marker2');
      d(el, 'marker2');
    }
    function testC(el) {
      Position.clone(el, 'marker3');
      d(el, 'marker3');
    }
    function testD(el) {
      Position.clone(el, 'marker4');
      d(el, 'marker4');
    }
    // ]]>
    </script>

    <div id="actions" style="position:absolute;top:400px;">
      <a href="#" onclick="Element.toggle('big'); return false;">Toggle page scrolling</a> |
      Page margings: <a href="#" onclick="document.body.className = 'margins'">on</a> |
      <a href="#" onclick="document.body.className = 'nomargins'">off</a>
      <br/><br/>
      Absolute marker in position:relative container DIV:<br/>
      <a href="#" onclick="testA('test1'); return false;">Mark abs</a> |
      <a href="#" onclick="testA('test2'); return false;">Mark rel</a> |
      <a href="#" onclick="testA('test3'); return false;">Mark static</a> |
      <a href="#" onclick="testA('c3'); return false;">Mark abs-body child</a> |
      <a href="#" onclick="testA('p1'); return false;">Mark p</a>
      <br/><br/>
      Hidden marker (display:none), in position:relative container DIV switched on when clone is finished:<br/>
      <a href="#" onclick="testB('test1'); return false;">Mark abs</a> |
      <a href="#" onclick="testB('test2'); return false;">Mark rel</a> |
      <a href="#" onclick="testB('test3'); return false;">Mark static</a> |
      <a href="#" onclick="testB('c3'); return false;">Mark abs-body child</a> |
      <a href="#" onclick="testB('p1'); return false;">Mark p</a>
      <br/><br/>
      Absolute marker, child of BODY:<br/>
      <a href="#" onclick="testC('test1'); return false;">Mark abs</a> |
      <a href="#" onclick="testC('test2'); return false;">Mark rel</a> |
      <a href="#" onclick="testC('test3'); return false;">Mark static</a> |
      <a href="#" onclick="testC('c3'); return false;">Mark abs-body child</a> |
      <a href="#" onclick="testC('p1'); return false;">Mark p</a>
      <br/><br/>
      Fixed marker, child of BODY:<br/>
      <a href="#" onclick="testD('test1'); return false;">Mark abs</a> |
      <a href="#" onclick="testD('test2'); return false;">Mark rel</a> |
      <a href="#" onclick="testD('test3'); return false;">Mark static</a> |
      <a href="#" onclick="testD('c3'); return false;">Mark abs-body child</a> |
      <a href="#" onclick="testD('p1'); return false;">Mark p</a> |
      <div id="debug"></div>
   </div>

   <div id="marker-container" style="position:relative;left:400px;top:20px;width:100px;height:100px;">
     <div id="blah" style="top:20px;">
     <div id="marker" style="position:absolute;background-color:#f00;opacity:0.5;z-index:10000;width:10px;height:10px;">!</div>
     </div>
     <div id="marker2" style="display:none;position:absolute;background-color:#0f0;opacity:0.5;z-index:10000;width:10px;height:10px;">!</div>
  </div>
  
  

  <div id="marker3" style="position:absolute;background-color:#00f;opacity:0.5;z-index:10000;width:10px;height:10px;">!</div>
  
  <div id="marker4" style="position:fixed;background-color:#08f;opacity:0.5;z-index:10000;width:10px;height:10px;">!</div>

  <div id="big" style="display:none;height:10000px;"> </div>

  </body>
</html>
