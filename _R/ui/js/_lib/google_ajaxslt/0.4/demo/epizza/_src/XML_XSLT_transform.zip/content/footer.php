<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>EvifWeb Development</title>
</head>

<body>
&copy; <?php echo date(Y); ?> EvifWeb Development
</body>
</html>